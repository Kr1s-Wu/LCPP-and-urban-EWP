#1.导入面板数据
setwd("C:\\Users\\Asus\\Desktop\\1论文\\低碳试点与生态福利绩效\\筛选数据")
library(openxlsx) 
library(plm)

data<-read.xlsx("最终数据.xlsx",sheet = 1)

#1.1解释变量与被解释变量处理
mydata <- data.frame(EWP=data$EWP,city=data$城市,year=data$year,province=data$所属省份名称)
mydata$DID <- data$policy*data$post

#1.2控制变量处理
mydata$UR <- data$城镇化率
mydata$PD <- data$`全市常住人口（万人）`/data$`行政区域土地面积（平方公里）全市`
mydata$TP <- data$`科学技术支出（万元）全市`/data$实际GDP万元
mydata$UG <- data$`城市园林绿化-公园绿地面积_公顷`/data$`全市常住人口（万人）`
mydata$GOV <- data$`地方一般公共预算支出（万元）全市`/data$`地方一般公共预算收入（万元）全市`
mydata$EDU <- data$`每万人普通高等学校学生数（人）`
mydata$GDPGrowth <- data$地区生产总值增速/100
mydata$FDI <- data$FDI万美元*data$汇率/data$实际GDP万元
mydata$PGDP <- data$实际GDP万元/data$`全市常住人口（万人）`
mydata$GDP <- log(data$实际GDP万元)
mydata$Size <- log(data$`全市常住人口（万人）`)

#1.3制成面板数据
Pannel_data<-pdata.frame(mydata,index=c("city","year"))

#2.安慰剂检验
library(tidyr)
newdata <- Pannel_data[,c(2,3)]
n=500#抽样次数
m=length(unique(mydata$city))#所有城市个数
city <- matrix(NA,nrow=m,ncol=n)
data <- matrix(NA,nrow=121,ncol=n)
#随机抽样：121个试点城市
for (i in 1:500) {
  city[,i] <- unique(mydata$city)
  data[,i] <- c(sample(size=121,city[,i],replace = F))
}
#确认是否重复抽样
length(unique(data[,1]))
length(unique(data[,250]))
length(unique(data[,500]))

city <- as.data.frame(data)

city.1 <- city[c(1:70),]
city.2 <- city[c(71:94),]
city.3 <- city[c(95:121),]
city.1 <- city.1[rep(1:nrow(city.1),each=14),] %>% as.data.frame()
city.2 <- city.2[rep(1:nrow(city.2),each=14),] %>% as.data.frame()
city.3 <- city.3[rep(1:nrow(city.3),each=14),] %>% as.data.frame()
city.1$year <- rep(c(2006:2019),times=length(unique(city.1$V1)))
city.2$year <- rep(c(2006:2019),times=length(unique(city.2$V1)))
city.3$year <- rep(c(2006:2019),times=length(unique(city.3$V1)))
#设定试点虚拟变量

city.1$DID[city.1$year>2010]=1
city.2$DID[city.2$year>2013]=1
city.3$DID[city.3$year>2017]=1
city.1[is.na (city.1)]=0
city.2[is.na (city.2)]=0
city.3[is.na (city.3)]=0
city <- rbind(city.1,city.2,city.3)
all_city <- unique(mydata$city) %>% as.data.frame()
non_city <- list()
#筛选非试点城市
for (i in 1:n) {
  non_city[i] <- subset(all_city,!all_city$.%in%c (unique(city[,i])))
  non_city <- data.frame(non_city)
  
}
colnames(non_city) <- paste(rep("V",each=n),c(1:500),sep = "")
non_city <- non_city[rep(1:nrow(non_city),each=14),] %>% as.data.frame()
non_city$year <- rep(c(2006:2019),times=length(unique(non_city$V1)))
non_city$DID=0
all_city=rbind(city,non_city)
all_city=data.frame(DID=all_city$DID,year=all_city$year,all_city)
all_city=all_city[,-c(n+3,n+4)]

#检验匹配成功
length(unique(all_city$V1))
length(unique(all_city$V250))
length(unique(all_city$V500))


newdata <- list()
x <- list()
for (i in 1:ncol(all_city)) {
  x[[i]] <- all_city[,i]
}
for (i in 1:n) {
  newdata[[i]] <- cbind(x[[1]],x[[2]],x[[i+2]])
  colnames(newdata[[i]]) <- c("DID","year","city")
}
Pannel_data <- Pannel_data[,-5]
for (i in 1:n) {
  newdata[[i]] <- merge(Pannel_data,newdata[[i]],by=c("city","year"))
}

#制成面板数据
for (i in 1:n) {
  newdata[[i]] <- pdata.frame(newdata[[i]],index = c("city","year"))
}

#得到估计系数
Estimate <- data.frame(Estimatation=NA,P=NA)
for (i in 1:n) {
  #获取估计系数
  Estimate[i,1] <-  summary(plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth
                              ,model = "within",effect = "twoways",newdata[[i]]))$coefficients[1,1]
  #获取概率值
  Estimate[i,2] <-  summary(plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth
                              ,model = "within",effect = "twoways",newdata[[i]]))$coefficients[1,4]
}




#绘制安慰剂检验图
library(ggplot2)
ggplot(Estimate) + 
  geom_point(aes(x = Estimatation,y = P*10),color= "#990033") +#密度图
  geom_density(mapping = aes(x = Estimatation),color="#330099")+
  theme(legend.title = element_blank(),title = NULL,panel.background = NULL, panel.grid.minor = element_blank(),panel.grid.major =  element_blank(),#调整背景板
        axis.text.x = element_text(size = 15),axis.text.y = element_text(size = 15),#刻度大小
        axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15),plot.title = element_text(hjust = 0.5,size=15))+#刻度标签大小
  scale_x_continuous(limits = c(-0.15, 0.15),breaks=seq(-0.1, 0.15, 0.05)) +#调整刻度范围
  scale_y_continuous(expand = c(0,0),limits = c(0,15),
                     sec.axis = sec_axis(~./10,
                                         name = 'P Value',
                                         breaks = seq(0,1,0.2)))+
  xlab("Estimate") + ylab("Density")+ ggtitle("Placebo test")+geom_vline(aes(xintercept = 0.1013),linetype="dashed")






