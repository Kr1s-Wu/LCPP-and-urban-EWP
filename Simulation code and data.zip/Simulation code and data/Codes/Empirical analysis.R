# **`1.生成空间权重矩阵`**

## **`1.1读取国家经纬度数据并生成地理距离权重矩阵`**

setwd("C:\\Users\\Asus\\Desktop")
library(geosphere)
library(openxlsx)
library(dplyr)
data<-read.xlsx("C:\\Users\\Asus\\Desktop\\低碳试点与生态福利绩效\\筛选数据\\最终数据.xlsx",sheet = 2 )
city.lonlat =cbind (data[,2],data[,3])
city.lonlat <- as.data.frame(unique(city.lonlat))
city.lonlat <- data.frame(as.numeric(city.lonlat$V1),as.numeric(city.lonlat$V2))
city.dists.weight = distm(city.lonlat, fun=distVincentyEllipsoid)
city.dis.w<- 1/city.dists.weight*10000
city.dis.w[city.dis.w==Inf]<-0
#行标准化处理
k = length(unique(data$城市))
cityname <- unique(data$城市)
dis.w<-city.dis.w/rowSums(city.dis.w)
colnames(dis.w) <- cityname
dis.w <- as.data.frame(dis.w)
dis.w
dis.w[,k+1] <- cityname
write.xlsx(dis.w,"C:\\Users\\Asus\\Desktop\\低碳试点与生态福利绩效\\筛选数据\\地理权重矩阵.xlsx")


## 1.2生成经济距离权重矩阵
data<-read.xlsx("C:\\Users\\Asus\\Desktop\\低碳试点与生态福利绩效\\筛选数据\\最终数据.xlsx",sheet = 1 )
data.GDP.1<- data[,c(1,8)]
list.data.GDP<-list()
GDP.mean<-aggregate(data.GDP.1[,2],by=list(data[,1]),mean)
k = length(unique(data$城市))
weight.GDP<-matrix(NA,ncol=k,nrow=k)
for(i in 1:k){
  for(j in 1:k){
    weight.GDP[i,j]<-1/abs(GDP.mean[,2][i]-GDP.mean[,2][j])
  }
}
weight.GDP[which(weight.GDP==Inf)]=0
eco.w<-weight.GDP/rowSums(weight.GDP)
colnames(eco.w) <- cityname
rownames(eco.w) <- cityname
eco.w <- as.data.frame(eco.w)
eco.w
eco.w[,k+1] <- rownames(eco.w)


write.xlsx(eco.w,"C:\\Users\\Asus\\Desktop\\低碳试点与生态福利绩效\\筛选数据\\经济权重矩阵.xlsx")
## 1.3生成地理经济距离权重矩阵
eco.w <- eco.w[,-c(k+1)] %>% as.matrix()
dis.w <- dis.w[,-c(k+1)] %>% as.matrix()
geo.eco.w<-(dis.w+eco.w)/2
geo.eco.w <- as.data.frame(geo.eco.w)
geo.eco.w[,k+1] <- rownames(eco.w)
write.xlsx(geo.eco.w,"C:\\Users\\Asus\\Desktop\\低碳试点与生态福利绩效\\筛选数据\\经济地理权重矩阵.xlsx")

#2.计算绿色金融指数
#编写函数
#正向指标函数
postive<-function(x){
  (x-min(x))/(max(x)-min(x))
}
#逆向指标函数
negative<-function(x){
  (max(x)-x)/(max(x)-min(x))
}
data$fina1 <- data$fiinanceloan1/data$GDP1
data$fina2 <- data$fiinanceloan1/data$fiinancedeposit1
data$gree <- (data$so21+data$wastewater1+data$dust1)/data$GDP1
data$gree <- negative(data$gree)
data$gfin1 <- abs((data$fina1*data$gree)/(data$fina1+data$gree)**2)*(data$fina1+data$gree)
data$gfin2 <- abs((data$fina2*data$gree)/(data$fina2+data$gree)**2)*(data$fina2+data$gree)




##                                   实证分析

#三大空间计量模型解释
#空间滞后模型自回归模型（Autoregressive Model，AR）在时间序列分析中很易理解，即因变量与它的时间滞后值（Lag）存在相关性，这也意味着自回归模型放弃了因变量独立性的假设。
#在空间计量模型中，空间滞后值被认为是邻近空间单元的属性（加权）值，因此下面是一个形式比较简单的空间自回归模型（最简单的形式应该是不包含自变量），也就是空间滞后模型（Spatial Lagged Model，SLR）：
#空间误差模型
#空间误差模型（Spatial Error Model，SEM）可以分解成如下两步：
#上述两式合并得，
#第一个式子并非线性模型，因为不需要服从正态分布；
#模型估计时会首先对参数进行估计，再使用广义最小二乘法估计和其他参数。
#空间杜宾模型（Spatial Durbin Model，SDM）
#假定因变量取值除受本地自变量的影响外，
#还会受到邻近地区的自变量影响，即在模型中加入自变量的空间滞后值：
#1.导入面板数据

setwd("C:\\Users\\Asus\\Desktop\\1论文\\低碳试点与生态福利绩效\\筛选数据")
library(openxlsx) 
library(plm)
library(lmtest)
data<-read.xlsx("最终数据.xlsx",sheet = 1)

#1.1解释变量与被解释变量处理
mydata <- data.frame(EWP=data$EWP,city=data$城市,id=data$市级行政代码,year=data$year,province=data$所属省份名称)

mydata$DID <- data$policy*data$post
mydata$post <- data$post
mydata$policy <- data$policy

#1.2控制变量处理
mydata$UR <- data$城镇化率
mydata$PD <- data$`全市常住人口（万人）`/data$`行政区域土地面积（平方公里）全市`
mydata$TP <- data$`科学技术支出（万元）全市`/data$实际GDP万元
mydata$UG <- data$`城市园林绿化-公园绿地面积_公顷`/data$`全市常住人口（万人）`
mydata$GOV <- data$`地方一般公共预算支出（万元）全市`/data$`地方一般公共预算收入（万元）全市`
mydata$EDU <- data$`每万人普通高等学校学生数（人）`
mydata$GDPGrowth <- data$地区生产总值增速/100
mydata$FDI <- data$FDI万美元*data$汇率/data$实际GDP万元
mydata$PGDP <- data$实际GDP万元/data$`全市常住人口（万人）`
mydata$GDP <- log(data$实际GDP万元)


#1.3机制分析变量
#1.3.1绿色技术创新
mydata$GP <- data$绿色专利授权总量/data$`全市常住人口（万人）`
#1.3.2产业结构调整
mydata$IS <- data$`第三产业增加值(万元)`/data$`第二产业增加值(万元)`
mydata$IS <- mydata$IS-mean(mydata$IS)
mydata$DID_IS <- mydata$IS*mydata$DID
#1.4异质性分析变量
mydata$resource <- data$resource_city
mydata$Region <- data$经济区域
mydata$Energy <- data$全社会用电量万千瓦时/data$`全市常住人口（万人）`
#1.5制成面板数据
Pannel_data<-pdata.frame(mydata,index=c("city","year"))

library(ggplot2)
EWP <- aggregate(mydata$EWP,by=list(mydata$year),mean)
colnames(EWP) <- c("year","EWP")
x <- c()
for (i in 1:length(EWP$year)) {
  x[i] <- EWP$EWP[i]-EWP$EWP[i-1]
}
x <- x*100
x <- round(x,digits = 2)
EWP$EWP <- round(EWP$EWP,digits = 3)
EWP$Rate <- x


EWP <- rbind(EWP1,EWP2)
EWP$type=rep(c("mean","median"),each=14)
ggplot(EWP, aes(x = year,y=EWP))+ geom_point(aes(year, EWP,color=type),size=3)+
  geom_line(aes(year, EWP,color=type),size=1)+#密度曲线函数
  theme(legend.title = element_blank(),title = NULL,panel.background = NULL, panel.grid.minor = element_blank(),panel.grid.major =  element_blank(),#调整背景板
        axis.text.x = element_text(size = 15),axis.text.y = element_text(size = 15),#刻度大小
        axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15),plot.title = element_text(hjust = 0.5,size=15))+#刻度标签大小
  scale_x_continuous(breaks = seq(2006,2019,1))+#调整刻度范围
  xlab("Year") + ylab("EWP")



#2.基准回归
base1 <- plm(EWP ~ DID ,
            model = "within",effect = "twoways",Pannel_data)
summary(base1)
base2 <- plm(EWP ~ DID + FDI ,
            model = "within",effect = "twoways",Pannel_data)
summary(base2)
base3 <- plm(EWP ~ DID + FDI + EDU ,
            model = "within",effect = "twoways",Pannel_data)
summary(base3)
base4 <- plm(EWP ~ DID + FDI + EDU + GOV ,
            model = "within",effect = "twoways",Pannel_data)
summary(base4)
base5 <- plm(EWP ~ DID + FDI + EDU + GOV + TP ,
            model = "within",effect = "twoways",Pannel_data)
summary(base5)
base6 <- plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
            model = "within",effect = "twoways",Pannel_data)
summary(base6)
#导出回归结果
library(stargazer)
#将t=改为（位于第7105行
trace(stargazer:::.stargazer.wrap,edit=T)
stargazer(base1,base2,base3,base4,base5,base6,
          type="html",title = "基准回归",no.space=T,align=T,report="vc*t",
          out="C:\\Users\\Asus\\Desktop\\低碳试点与生态福利绩效\\实证分析\\基准回归与稳健性检验\\基准回归.doc")

#3.稳健性检验
 #3.1以城市作为聚类变量
robust1 <- coeftest(base6,vcov. = vcovBK(base6,type="HC0",cluster="group"))
robust1
 #3.2剔除直辖市,省会
robust2 <- plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
               model = "within",effect = "twoways",
               Pannel_data,subset = !Pannel_data$city %in% c( "北京市","上海市","天津市","重庆市","哈尔滨市","长春市","沈阳市","呼和浩特市","石家庄市","乌鲁木齐市","兰州市","西宁市","西安市","银川市","郑州市","济南市","太原市","合肥市","武汉市","长沙市","南京市","成都市","贵阳市","昆明市","南宁市","拉萨市","杭州市","南昌市","广州市","福州市","台北市","海口市","香港市","澳门市"))
summary(robust2)
 #3.3#剔除其他政策试点城市：创新型试点和碳交易试点
robust3 <- plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
               model = "within",effect = "twoways",
               Pannel_data,subset = !Pannel_data$city %in% c("包头市","北京市","昌吉市","潮州市","成都市","东莞市","鄂州市","佛山市","福州市","广州市","哈尔滨市","海口市","合肥市","河源市","呼和浩特市","湖州市","黄冈市","黄石市","惠州市","济南市","济宁市","嘉兴市","江门市","揭阳市","荆门市","荆州市","兰州市","连云港市","龙岩市","洛阳市","茂名市","梅州市","南平市","南通市","南阳市","宁波市","宁德市","萍乡市","莆田市","秦皇岛市","青岛市","清远市","泉州市","三明市","厦门市","汕头市","汕尾市","上海市","韶关市","深圳市","沈阳市市","十堰市","石河子市","随州市","泰州市","唐山市","天津市","乌鲁木齐市","武汉市","西安市","西宁市","咸宁市","襄阳市","孝感市","盐城市","扬州市","阳江市","宜昌市","云浮市","湛江市","漳州市","长春市","长沙市","肇庆市","郑州市","中山市","重庆市","珠海市","遵义市"))
summary(robust3)


#3.4PSM-DID检验：1：1最邻近匹配
library(MatchIt)
library(dplyr)
library(ggplot2)
library(tableone)

mod_match <- matchit(DID ~  FDI + EDU + GOV + TP + GDPGrowth,ratio = 1,#开始匹配
                     method = "nearest" , data = mydata)

mathch_data<- match.data(mod_match)#匹配后的结果

dim(mathch_data)#检查匹配数量
#进行回归
PSM_data<-pdata.frame(mathch_data,index=c("city","year"))
PSM_DID <- plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
               model = "within",effect = "twoways",PSM_data)
summary(PSM_DID)

CreateTableOne(vars = c("DID","FDI" ,"EDU","GOV" ,"TP", "GDPGrowth"),#平衡性检查
               strata = "DID",data = mydata)
CreateTableOne(vars = c("DID","FDI" ,"EDU","GOV" ,"TP", "GDPGrowth"),#平衡性检查
               strata = "DID",data = mathch_data)


m_pre <- glm( DID ~  FDI + EDU + GOV + TP + GDPGrowth,#匹配前倾向性得分计算
              family = binomial(link = "logit"), data = mydata)
summary(m_pre)
pre_df <- data.frame(pre_score = predict(m_pre, type = "response"),#匹配前倾向性得分计算
                     DID = as.factor(m_pre$model$DID))


m_after <- glm( DID ~ FDI + EDU + GOV + TP + GDPGrowth,#匹配后倾向性得分计算
                family = binomial(), data = mathch_data)
summary(m_after)
after_df <- data.frame(pre_score = predict(m_after, type = "response"),
                       DID = as.factor(m_after$model$DID))#匹配后倾向性得分计算

#匹配前密度得分倾向值密度分布
ggplot(pre_df, aes(x = pre_score))+ 
  geom_density(aes(color = DID),size=1)+#密度曲线函数
  theme(legend.title = element_blank(),title = NULL,panel.background = NULL, panel.grid.minor = element_blank(),panel.grid.major =  element_blank(),#调整背景板
        axis.text.x = element_text(size = 15),axis.text.y = element_text(size = 15),#刻度大小
        axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15),plot.title = element_text(hjust = 0.5,size=15))+#刻度标签大小
  scale_x_continuous()+#调整刻度范围
  xlab("propensity score") + ylab("Density")+ ggtitle("Pre-match Propensity score distributions")

#匹配后密度得分倾向值密度分布
ggplot(after_df, aes(x = pre_score))+ 
  geom_density(aes(color = DID),size=1)+#密度曲线函数
  theme(legend.title = element_blank(),title = NULL,panel.background = NULL, panel.grid.minor = element_blank(),panel.grid.major =  element_blank(),#调整背景板
        axis.text.x = element_text(size = 15),axis.text.y = element_text(size = 15),#刻度大小
        axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15),plot.title = element_text(hjust = 0.5,size=15))+#刻度标签大小
  scale_x_continuous()+#调整刻度范围
  xlab("propensity score") + ylab("Density")+ ggtitle("Post-match Propensity score distributions")

#导出稳健性检验回归结果
stargazer(robust1,robust2,robust3,PSM_DID,
          type="html",title = "基准回归",no.space=T,align=T,report="vc*t",
          out="C:\\Users\\Asus\\Desktop\\低碳试点与生态福利绩效\\实证分析\\基准回归与稳健性检验\\稳健性检验.doc")


  #3.5平行趋势检验
   #3.5.1生成政策虚拟变量
mydata$pre1=data$pre1 
mydata$pre2=data$pre2
mydata$pre3=data$pre3
mydata$pre4=data$pre4
mydata$pre5=data$pre5
mydata$pre6=data$pre6
mydata$pre7=data$pre7
mydata$current=data$current
mydata$post1=data$post1
mydata$post2=data$post2
mydata$post3=data$post3
mydata$post4=data$post4
mydata$post5=data$post5
mydata$post6=data$post6
mydata$post7=data$post7
Pannel_data<-pdata.frame(mydata,index=c("city","year"))
Parallel <- EWP ~ pre7+ 
                  pre6+
                  pre5+
                  pre4+
                  pre3+
                  pre2+
                  pre1+
                  current+
                  post1+
                  post2+
                  post3+
                  post4+
                  post5+
                  post6+
                  post7+  FDI + EDU + GOV + TP + GDPGrowth
Parallel_test <- plm(Parallel,model = "within",effect = "twoways",Pannel_data)
summary(Parallel_test)
Coef <- summary(Parallel_test)$coefficients[c(1:15),1] %>% as.data.frame()
colnames(Coef) <- "Coef"
conf_interval  <- confint(Parallel_test,level = 0.90)[c(1:15),] %>% as.data.frame()
colnames(conf_interval) <- c("lower","upper")
conf_interval$t <- c(-7:7)
conf_interval$Coef <- Coef$Coef
conf_interval$factor <- c(rep("Pre treament",each=7),rep("Post treament",each=8))
  #3.5.2开始绘制
library(ggplot2)
ggplot(conf_interval,mapping = aes( x= t, y=Coef))+geom_point(aes(t, Coef, color = factor),size=3)+geom_line(mapping = aes(y = Coef, color = factor, group =1),size=1)+
  geom_errorbar(aes(t,y=Coef, color = factor,ymin = lower, ymax = upper), width = 0.2,size=1)+#绘制上下95%置信区间
  geom_hline(aes(yintercept=0), colour="darkorchid3", linetype="dashed",size=0.8)+#加0线
  theme(legend.position = "top", legend.title = element_blank(),title = NULL,panel.background = NULL, panel.grid.minor = element_blank(),panel.grid.major =  element_blank(),
        axis.text.x = element_text(size = 15),axis.text.y = element_text(size = 15),#刻度大小
        axis.title.x = element_text(size = 15),axis.title.y = element_text(size = 15),#刻度标签大小
        legend.text=element_text(size=15),
        legend.background = element_rect(
          fill = "lightblue", # 填充色
          colour = "black", # 框线色
          size = 0.5) )+
  scale_x_continuous(breaks=seq(-7, 7, 1)) + scale_y_continuous(breaks=seq(-0.2, 0.2, 0.05))+#调整刻度范围
  xlab("Time of implementation of the policy") + ylab("Dynamic effects")


#4.机制检验
 #4.1.绿色技术创新
GP_1 <- plm(GP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
            model = "within",effect = "twoways",Pannel_data)
summary(GP_1)
GP_2 <- EWP <- plm(EWP ~ DID + GP + FDI + EDU + GOV + TP + GDPGrowth,
                   model = "within",effect = "twoways",Pannel_data)
summary(GP_2)
 #4.2.产业结构调整
IS_1 <- plm(EWP ~ DID + IS + FDI + EDU + GOV + TP + GDPGrowth,
            model = "within",effect = "twoways",Pannel_data)
summary(IS_1)
IS_2 <- EWP <- plm(EWP ~ DID + IS + DID_IS + FDI + EDU + GOV + TP + GDPGrowth,
                   model = "within",effect = "twoways",Pannel_data)
summary(IS_2)
#导出机制回归结果
stargazer(GP_1,GP_2,IS_1,IS_2,
          type="html",title = "基准回归",no.space=T,align=T,report="vc*t",
          out="C:\\Users\\Asus\\Desktop\\低碳试点与生态福利绩效\\实证分析\\基准回归与稳健性检验\\机制分析.doc")

#5.异质性分析
 #5.1能源消耗异质性
  #5.1.1高能源消耗
High_E <- plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
             model = "within",effect = "twoways",Pannel_data,
             subset = Pannel_data$Energy>quantile(Pannel_data$Energy,0.8))
summary(High_E)
  #5.1.2低能源消耗
Low_E <- plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
                model = "within",effect = "twoways",Pannel_data,
                subset = Pannel_data$Energy<quantile(Pannel_data$Energy,0.2))
summary(Low_E)

 #5.2资源型城市异质性
  #5.2.1非资源型城市
non_res <- plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
                    model = "within",effect = "twoways",Pannel_data,
                    subset = Pannel_data$resource=="non_resource")
summary(non_res)
  #5.2.2资源型城市
res <- plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
                model = "within",effect = "twoways",Pannel_data,
                subset = Pannel_data$resource=="resource")
summary(res)

 #5.3经济区域异质性
  #5.3.1东北部
NE <- plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
                 model = "within",effect = "twoways",Pannel_data,
                 subset = Pannel_data$Region=="Northeast")
summary(NE)
  #5.3.2东部
E <- plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
                  model = "within",effect = "twoways",Pannel_data,
                  subset = Pannel_data$Region=="Eastern")
summary(E)
  #5.3.3中部
Cen <- plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
               model = "within",effect = "twoways",Pannel_data,
               subset = Pannel_data$Region=="Central")
summary(Cen)
  #5.3.4西部
W <- plm(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth,
               model = "within",effect = "twoways",Pannel_data,
               subset = Pannel_data$Region=="Western")
summary(W)
#导出异质性分析结果
stargazer(High_E,Low_E,non_res,res,NE,E,Cen,W,
          type="html",title = "基准回归",no.space=T,align=T,report="vc*t",
          out="C:\\Users\\Asus\\Desktop\\低碳试点与生态福利绩效\\实证分析\\基准回归与稳健性检验\\异质性分析.doc")


#6.空间计量分析
 #6.1 导入权重矩阵
setwd("C:\\Users\\Asus\\Desktop\\低碳试点与生态福利绩效\\筛选数据")
lapply(c("splm","spdep","spatialreg"), library, character.only = TRUE )

geography.weight<-read.xlsx("地理权重矩阵.xlsx") #读取地理空间权重矩阵数据
rownames(geography.weight) <- geography.weight$V280
geography.weight <- geography.weight[,-281]
geography.weight.matrix<-as.matrix(geography.weight) #将数据框转化为矩阵
sw1<-mat2listw(geography.weight.matrix,style="W")

economic.weight<-read.xlsx("经济权重矩阵.xlsx") #读取经济空间权重矩阵数据
rownames(economic.weight) <- economic.weight$V280
economic.weight <- economic.weight[,-281]
economic.weight.matrix<-as.matrix(economic.weight) #将数据框转化为矩阵
sw2<-mat2listw(economic.weight.matrix,style="W")

eco.geo.weight<-read.xlsx("经济地理权重矩阵.xlsx") #读取经济地理空间权重矩阵数据
rownames(eco.geo.weight) <- geography.weight$V280
eco.geo.weight <- eco.geo.weight[,-281]
eco.geo.weight.matrix<-as.matrix(eco.geo.weight) #将数据框转化为矩阵
sw3<-mat2listw(eco.geo.weight.matrix,style="W")
 #6.2Moran检验
  #6.2.1全局莫兰指数
moran_test_p <- list()
moran_test_t <- list()
moran_test_estimate <- list()
year <- c(2006:2019)
for (i in 1:length(year)) {
  moran_test_p[i] <- moran.test(mydata$EWP[which(data$year==year[i])],sw1)$p.value
  names(moran_test_p)[i] <- year[i]
  
  moran_test_estimate[i] <- moran.test(mydata$EWP[which(data$year==year[i])],sw1)$estimate[1]
  names(moran_test_estimate)[i] <- year[i]
  
  moran_test_t[i] <- moran.test(mydata$EWP[which(data$year==year[i])],sw1)$statistic
  names(moran_test_t)[i] <- year[i]
}
moran_test_t <- unlist(moran_test_t) %>% as.data.frame()
moran_test_p <- unlist(moran_test_p) %>% as.data.frame()
moran_test_estimate <- unlist(moran_test_estimate) %>% as.data.frame()
colnames(moran_test_t) <- c("t")
colnames(moran_test_p) <- c("p")
colnames(moran_test_estimate) <- c("estimate")
moran_test <- cbind(moran_test_estimate,moran_test_t,moran_test_p)
moran_test  #全局莫兰指数检验结果

write.xlsx(moran_test,"C:\\Users\\Asus\\Desktop\\低碳试点与生态福利绩效\\实证分析\\全局莫兰指数.xlsx")

#6.2.2局部MoranI
moran.plot(mydata$EWP[which(data$year==2006)],sw1,
           xlab="EWP in 2006", ylab="Spatially lagged EWP",
           labels=FALSE,pch=19,cex = 1.1, cex.axis=1.3,cex.lab=1.4)
moran.plot(mydata$EWP[which(data$year==2019)],sw1,
           xlab="EWP in 2019", ylab="Spatially lagged EWP",
           labels=FALSE,pch=19,cex = 1.1, cex.axis=1.3,cex.lab=1.4)

#6.3事前空间计量模型选择检验
fm1 <- EWP ~ DID  + FDI + EDU + GOV + TP + GDPGrowth 
fm2 <- EWP ~ DID + W_DID + FDI + EDU + GOV + TP + GDPGrowth + W_FDI + W_EDU + W_GOV + W_TP + W_GDPGrowth
slmtest(fm1,Pannel_data,listw=sw2,model="pooling",test="lml",effect="twoways")
slmtest(fm1,Pannel_data,listw=sw2,model="pooling",test="lme",effect="twoways")
slmtest(fm1,Pannel_data,listw=sw2,model="pooling",test="rlml",effect="twoways")
slmtest(fm1,Pannel_data,listw=sw2,model="pooling",test="rlme",effect="twoways")
sphtest(fm2,Pannel_data,index=c("city","year"),listw=sw1,spatial.model="sarar")



#LR检验和Wald检验
SAR_model <- spml(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth ,
                  Pannel_data,listw = sw1,model = "within",effect = "twoways",
                  lag=T,spatial.error="none")
SEM_model <- spml(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth ,
                         Pannel_data,listw = sw1,model = "within",effect = "twoways",
                         lag=F,spatial.error="b")
SDM_model <-spml(EWP ~ DID + FDI + EDU + GOV + TP + GDPGrowth + W_DID  + W_FDI + W_EDU + W_GOV + W_TP + W_GDPGrowth  ,
                                      Pannel_data,listw = sw1,model = "within",effect = "twoways",
                  lag=T,spatial.error="b")
logLik(SAR_model)
ll_SDM <- SDM_model$logLik
ll_SAR <- SAR_model$logLik
ll_SEM <- SEM_model$logLik
SAR_df <- length(coef(SDM_model)) - length(coef(SAR_model))
SEM_df <- length(coef(SDM_model)) - length(coef(SEM_model))
##LR检验
lr_SAR_stat <- -2 * (ll_SAR - ll_SDM)  
lr_SEM_stat <- -2 * (ll_SEM - ll_SDM)  
lr_SAR_p_value <- 1 - pchisq(lr_SAR_stat, SAR_df)
lr_SEM_p_value <- 1 - pchisq(lr_SEM_stat, SEM_df)
LR_stat <- c(lr_SAR_stat,lr_SEM_stat)
LR_p <- c(lr_SAR_p_value,lr_SEM_p_value)
LR_test <- data.frame(LR_stat=LR_stat,LR_p=LR_p)
rownames(LR_test) <- c(SAR,SEM)
LR_test
# 计算wald统计量

## 提取空间滞后项的系数估计  
lambda_hat <- SDM_model$arcoef 
rho_hat <- SDM_model$errcomp
## 提取空间滞后项系数的标准误差  
se_lambda <- sqrt(SDM_model$vcov.arcoef)
se_rho <- sqrt(SDM_model$vcov.errcomp)
## 计算Wald统计量  
rho_wald_stat <- (rho_hat / se_rho)^2  
lambda_wald_stat <- (lambda_hat / se_lambda)^2 
# 计算p值（基于卡方分布，自由度为1）  
rho_p_value <- 1 - pchisq(rho_wald_stat, df = 1)  
lambda_p_value <- 1 - pchisq(lambda_wald_stat, df = 1)  

wald_stat <- c(lambda_wald_stat,rho_wald_stat)
wald_p <- c(lambda_p_value,rho_p_value)
wald_test <- data.frame(Wald_stat=wald_stat,Wald_p=wald_p)
rownames(wald_test) <- c("SAR","SEM")
wald_test
#6.3地理权重矩阵估计结果
Pannel_data$W_DID<-slag(Pannel_data$DID,  sw1)
Pannel_data$W_EWP<-slag(Pannel_data$EWP,  sw1)
Pannel_data$W_UR <-slag(Pannel_data$UR,   sw1)
Pannel_data$W_PD <-slag(Pannel_data$PD,   sw1)
Pannel_data$W_FDI<-slag(Pannel_data$FDI,  sw1)
Pannel_data$W_UG<-slag(Pannel_data$UG,    sw1)
Pannel_data$W_PGDP<-slag(Pannel_data$PGDP,sw1)
Pannel_data$W_IS<-slag(Pannel_data$IS,    sw1)
Pannel_data$W_GOV<-slag(Pannel_data$GOV,  sw1)
Pannel_data$W_TP<-slag(Pannel_data$TP,    sw1)
Pannel_data$W_GDP<-slag(Pannel_data$GDP,  sw1)
Pannel_data$W_EDU<-slag(Pannel_data$EDU,  sw1)
Pannel_data$W_GDPGrowth<-slag(Pannel_data$GDPGrowth,  sw1)

spatial_lm1<-spml(EWP ~ DID + W_DID + FDI + EDU + GOV + TP + GDPGrowth + W_FDI + W_EDU + W_GOV + W_TP + W_GDPGrowth  ,
                  Pannel_data,listw = sw1,model = "within",effect = "twoways",
                  lag=T,spatial.error="b")
summary(spatial_lm1)

#经济权重矩阵估计结果
Pannel_data$W_DID<-slag(Pannel_data$DID,  sw2)
Pannel_data$W_EWP<-slag(Pannel_data$EWP,  sw2)
Pannel_data$W_UR <-slag(Pannel_data$UR,   sw2)
Pannel_data$W_PD <-slag(Pannel_data$PD,   sw2)
Pannel_data$W_FDI<-slag(Pannel_data$FDI,  sw2)
Pannel_data$W_UG<-slag(Pannel_data$UG,    sw2)
Pannel_data$W_PGDP<-slag(Pannel_data$PGDP,sw2)
Pannel_data$W_IS<-slag(Pannel_data$IS,    sw2)
Pannel_data$W_GOV<-slag(Pannel_data$GOV,  sw2)
Pannel_data$W_TP<-slag(Pannel_data$TP,    sw2)
Pannel_data$W_GDP<-slag(Pannel_data$GDP,  sw2)

spatial_lm2<-spml(EWP ~ DID + W_DID + FDI + EDU + GOV + TP + GDPGrowth + W_FDI + W_EDU + W_GOV + W_TP + W_GDPGrowth,
                  Pannel_data,listw = sw2,model = "within",effect = "twoways",
                  lag=T,spatial.error="b")
summary(spatial_lm2)

#经济地理权重矩阵估计结果
Pannel_data$W_DID<-slag(Pannel_data$DID,  sw3)
Pannel_data$W_EWP<-slag(Pannel_data$EWP,  sw3)
Pannel_data$W_UR <-slag(Pannel_data$UR,   sw3)
Pannel_data$W_PD <-slag(Pannel_data$PD,   sw3)
Pannel_data$W_FDI<-slag(Pannel_data$FDI,  sw3)
Pannel_data$W_UG<-slag(Pannel_data$UG,    sw3)
Pannel_data$W_PGDP<-slag(Pannel_data$PGDP,sw3)
Pannel_data$W_IS<-slag(Pannel_data$IS,    sw3)
Pannel_data$W_GOV<-slag(Pannel_data$GOV,  sw3)
Pannel_data$W_TP<-slag(Pannel_data$TP,    sw3)
Pannel_data$W_GDP<-slag(Pannel_data$GDP,  sw3)

spatial_lm3<-spml(EWP ~ DID + W_DID + FDI + EDU + GOV + TP + GDPGrowth + W_FDI + W_EDU + W_GOV + W_TP + W_GDPGrowth,
                  Pannel_data,listw = sw3,model = "within",effect = "twoways",
                  lag=T,spatial.error="b")
summary(spatial_lm3)


#导出异质性分析结果
stargazer(spatial_lm3,
          type="html",title = "基准回归",no.space=T,align=T,report="vc*t",
          out="C:\\Users\\Asus\\Desktop\\低碳试点与生态福利绩效\\实证分析\\基准回归与稳健性检验\\空间溢出效应分析.doc")


write.xlsx(Pannel_data,"C:\\Users\\Asus\\Desktop\\EWP2-23.xlsx")
